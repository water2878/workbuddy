---
name: wechat-exporter
description: >
  微信聊天记录自动化导出工具集。This skill should be used when the user wants to
  export WeChat contact lists or chat history from the WeChat PC desktop application
  on Windows. It automates screenshot + OCR workflows to extract nicknames and
  conversation messages, and saves results as TXT and HTML files on the Desktop.
---

# 微信导出工具集

## 概述

本 skill 包含 4 个 Python 脚本，覆盖从"获取通讯录昵称"到"批量导出全部聊天记录"的完整流程。

| 脚本 | 功能 |
|------|------|
| `get_contacts.py` | 自动滚动通讯录，OCR 识别所有联系人昵称，输出到桌面 `微信联系人昵称.txt` |
| `dedup_contacts.py` | 清洗昵称文件：全角转半角、去噪声前缀、精确去重 + 编辑距离模糊去重，原地覆盖保存 |
| `export_chat.py` | 读取昵称文件，逐一搜索联系人，截图 + OCR 导出聊天记录（TXT + HTML），保存到桌面批量导出目录 |
| `wechat_all_in_one.py` | 一键版：自动执行"获取通讯录 → 去重 → 批量导出"全流程 |

## 依赖环境

- Python 3.8+（Windows）
- `paddleocr`（PaddleOCR 2.9.1 CPU 版）
- `pyautogui`、`pyperclip`、`numpy`、`Pillow`

安装依赖：
```bash
pip install paddleocr pyautogui pyperclip numpy Pillow
```

## 使用流程

### 方式 A：一键全流程（推荐）

```bash
python scripts/wechat_all_in_one.py
```

运行前确保微信 PC 端已登录并处于前台；脚本会自动：
1. 切换到通讯录，逐屏截图并 OCR 识别昵称
2. 写入 `<输出目录>/联系人昵称.txt`
3. 逐一搜索每个联系人，截图 + OCR 提取聊天记录
4. 每个联系人生成 `<名称>_聊天记录.txt` 和 `<名称>_聊天记录.html`
5. 完成后自动打开输出目录

输出路径：桌面 `微信全量导出_YYYYMMDD_HHMMSS/`

### 方式 B：分步执行

**Step 1 — 抓取通讯录昵称**

```bash
python scripts/get_contacts.py
```

输出：桌面 `微信联系人昵称.txt`（每行一个昵称）

**Step 2 — 清洗去重（可选）**

```bash
python scripts/dedup_contacts.py
```

原地覆盖 `微信联系人昵称.txt`，打印删除详情

**Step 3 — 批量导出聊天记录**

```bash
python scripts/export_chat.py
```

读取桌面 `微信联系人昵称.txt`，逐一导出，输出到桌面 `微信批量导出_YYYYMMDD_HHMMSS/`

## 关键配置项

所有脚本顶部均有 `★ 配置` 区域，常用参数：

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `SELF_NAME` | 聊天记录中代表自己的名称 | `"我"` |
| `MAX_SCROLLS` / `CHAT_MAX_SCROLLS` | 最多翻页次数 | `600` |
| `SCROLL_PAUSE` | 翻页间隔（秒） | `0.3` |
| `LEFT_THRESH` / `RIGHT_THRESH` | 气泡左/右判断阈值（相对宽度比） | `0.45 / 0.55` |
| `_CONTACTS_FILE` | 昵称列表文件路径 | 桌面 `微信联系人昵称.txt` |

## 注意事项

- 运行过程中**不要移动鼠标、不要操作键盘**，脚本使用 pyautogui 全自动控制界面
- 微信 PC 窗口需处于**前台可见**状态（脚本会自动置顶）
- 首次运行 PaddleOCR 会下载模型（约 100 MB），需联网
- 导出内容为 OCR 文字识别结果，图片/语音/视频消息不会被导出
- 若联系人搜索结果不唯一，`enter` 会进入第一个匹配项
